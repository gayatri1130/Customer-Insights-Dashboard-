select * from customer;
select first_name || ' ' || last_name  as full_name , email
from customer
where active = 1 ;

select count(*) as  total_customer  from customer;

select * from customer
where create_date > '2006-02-14';

select * from customer
where active = 0;


select store_id , count(*) as customer_count 
from customer	
group by store_id;

select * from customer
where email	like '%@sakilacustomer.org';